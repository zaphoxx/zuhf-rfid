/*
	RFID_CC1101.cpp - CC1101 module library
	Copyright (c) 2010 Michael.
  	Author: Michael, <www.RFID.com>
  	Version: November 12, 2010

	This library is designed to use CC1101/CC1100 module on Arduino platform.
	CC1101/CC1100 module is an useful wireless module.Using the functions of the 
	library, you can easily send and receive data by the CC1101/CC1100 module. 
	Just have fun!
	For the details, please refer to the datasheet of CC1100/CC1101.
*/
#include <ZUHF_CC1101.h>
#include <arduino.h>

/****************************************************************/
#define 	WRITE_BURST     	0x40						//write burst
#define 	READ_SINGLE     	0x80						//read single
#define 	READ_BURST      	0xC0						//read burst
#define 	BYTES_IN_RXFIFO     0x7F  						//byte number in RXfifo

/****************************************************************/
byte PaTabel[8] = {0x00 ,0xc0 ,0x00 ,0x00 ,0x00 ,0x00 ,0x00 ,0x00};

/****************************************************************
*FUNCTION NAME:SpiInit
*FUNCTION     :spi communication initialization
*INPUT        :none
*OUTPUT       :none
****************************************************************/
void ZUHF_CC1101::SpiInit(void)
{
  // initialize the SPI pins
  pinMode(SCK_PIN, OUTPUT);
  pinMode(MOSI_PIN, OUTPUT);
  pinMode(MISO_PIN, INPUT);
  pinMode(SS_TX, OUTPUT);
  pinMode(SS_RX, OUTPUT);

  // enable SPI Master, MSB, SPI mode 0, FOSC/4
  SpiMode(0);
}
/****************************************************************
*FUNCTION NAME:SpiMode
*FUNCTION     :set spi mode
*INPUT        :        config               mode
			   (0<<CPOL) | (0 << CPHA)		 0
			   (0<<CPOL) | (1 << CPHA)		 1
			   (1<<CPOL) | (0 << CPHA)		 2
			   (1<<CPOL) | (1 << CPHA)		 3
*OUTPUT       :none
****************************************************************/
void ZUHF_CC1101::SpiMode(byte config)
{
  byte tmp;

  // enable SPI master with configuration byte specified
  SPCR = 0;
  SPCR = (config & 0x7F) | (1<<SPE) | (1<<MSTR);
  tmp = SPSR;
  tmp = SPDR;
}

/****************************************************************
*FUNCTION NAME:SpiTransfer
*FUNCTION     :spi transfer
*INPUT        :value: data to send
*OUTPUT       :data to receive
****************************************************************/
byte ZUHF_CC1101::SpiTransfer(byte value)
{
  SPDR = value;
  while (!(SPSR & (1<<SPIF))) ;
  return SPDR;
}

/****************************************************************
*FUNCTION NAME: GDO_Set()
*FUNCTION     : set GDO0_TX,GDO2_TX pin
*INPUT        : none
*OUTPUT       : none
****************************************************************/
void ZUHF_CC1101::GDO_Set (void)
{
	pinMode(GDO0_TX, INPUT);
	pinMode(GDO2_TX, INPUT);
	pinMode(GDO0_RX, INPUT);
	pinMode(GDO2_RX, INPUT);
}

/****************************************************************
*FUNCTION NAME:Reset
*FUNCTION     :CC1101 reset //details refer datasheet of CC1101/CC1100//
*INPUT        :none
*OUTPUT       :none
****************************************************************/
void ZUHF_CC1101::Reset (byte ss_pin)
{
	digitalWrite(ss_pin, LOW);
	delay(1);
	digitalWrite(ss_pin, HIGH);
	delay(1);
	digitalWrite(ss_pin, LOW);
	while(digitalRead(MISO_PIN));
	SpiTransfer(CC1101_SRES);
	while(digitalRead(MISO_PIN));
	digitalWrite(ss_pin, HIGH);
/*
	Note that the above reset procedure is
	only required just after the power supply is
	first turned on. If the user wants to reset
	the CC1101 after this, it is only necessary to
	issue an SRES command strobe
*/
}

/****************************************************************
*FUNCTION NAME:Init
*FUNCTION     :CC1101 initialization
*INPUT        :none
*OUTPUT       :none
****************************************************************/
void ZUHF_CC1101::Init(byte ss_pin)
{
	SpiInit();										//spi initialization
	GDO_Set();										//GDO set
	digitalWrite(ss_pin, HIGH);
	digitalWrite(SCK_PIN, HIGH);
	digitalWrite(MOSI_PIN, LOW);
	Reset(ss_pin);										//CC1101 reset
	RegConfigSettings(ss_pin);							//CC1101 register config
	SpiWriteBurstReg(ss_pin,CC1101_PATABLE,PaTabel,8);		//CC1101 PATABLE config
}


/****************************************************************
*FUNCTION NAME:SpiWriteReg
*FUNCTION     :CC1101 write data to register
*INPUT        :addr: register address; value: register value
*OUTPUT       :none
****************************************************************/
void ZUHF_CC1101::SpiWriteReg(byte ss_pin, byte addr, byte value)
{
	digitalWrite(ss_pin, LOW);
	while(digitalRead(MISO_PIN));
	SpiTransfer(addr);
	SpiTransfer(value);
	digitalWrite(ss_pin, HIGH);
}

/****************************************************************
*FUNCTION NAME:SpiWriteBurstReg
*FUNCTION     :CC1101 write burst data to register
*INPUT        :addr: register address; buffer:register value array; num:number to write
*OUTPUT       :none
****************************************************************/
void ZUHF_CC1101::SpiWriteBurstReg(byte ss_pin, byte addr, byte *buffer, byte num)
{
	byte i, temp;

	temp = addr | WRITE_BURST;
    digitalWrite(ss_pin, LOW);
    while(digitalRead(MISO_PIN));
    SpiTransfer(temp);
    for (i = 0; i < num; i++)
 	{
        SpiTransfer(buffer[i]);
    }
    digitalWrite(ss_pin, HIGH);
}

/****************************************************************
*FUNCTION NAME:SpiStrobe
*FUNCTION     :CC1101 Strobe
*INPUT        :strobe: command; //refer define in CC1101.h//
*OUTPUT       :none
****************************************************************/
void ZUHF_CC1101::SpiStrobe(byte ss_pin, byte strobe)
{
	digitalWrite(ss_pin, LOW);
	while(digitalRead(MISO_PIN));
	SpiTransfer(strobe);
	digitalWrite(ss_pin, HIGH);
}

/****************************************************************
*FUNCTION NAME:SpiReadReg
*FUNCTION     :CC1101 read data from register
*INPUT        :addr: register address
*OUTPUT       :register value
****************************************************************/
byte ZUHF_CC1101::SpiReadReg(byte addr) 
{
	byte temp, value;

    temp = addr|READ_SINGLE;
	digitalWrite(SS_TX, LOW);
	while(digitalRead(MISO_PIN));
	SpiTransfer(temp);
	value=SpiTransfer(0);
	digitalWrite(SS_TX, HIGH);

	return value;
}

/****************************************************************
*FUNCTION NAME:SpiReadBurstReg
*FUNCTION     :CC1101 read burst data from register
*INPUT        :addr: register address; buffer:array to store register value; num: number to read
*OUTPUT       :none
****************************************************************/
void ZUHF_CC1101::SpiReadBurstReg(byte addr, byte *buffer, byte num)
{
	byte i,temp;

	temp = addr | READ_BURST;
	digitalWrite(SS_TX, LOW);
	while(digitalRead(MISO_PIN));
	SpiTransfer(temp);
	for(i=0;i<num;i++)
	{
		buffer[i]=SpiTransfer(0);
	}
	digitalWrite(SS_TX, HIGH);
}

/****************************************************************
*FUNCTION NAME:SpiReadStatus
*FUNCTION     :CC1101 read status register
*INPUT        :addr: register address
*OUTPUT       :status value
****************************************************************/
byte ZUHF_CC1101::SpiReadStatus(byte addr) 
{
	byte value,temp;

	temp = addr | READ_BURST;
	digitalWrite(SS_TX, LOW);
	while(digitalRead(MISO_PIN));
	SpiTransfer(temp);
	value=SpiTransfer(0);
	digitalWrite(SS_TX, HIGH);

	return value;
}

/****************************************************************
*FUNCTION NAME:RegConfigSettings
*FUNCTION     :CC1101 register config //details refer datasheet of CC1101/CC1100//
*INPUT        :none
*OUTPUT       :none
****************************************************************/


void ZUHF_CC1101::RegConfigSettings(byte ss_pin){
/* custom initial register settings for CC1101 
* Register Setup for
*  910e6 Hz
*  datarate 80kBaud
*  ASK/OOK modulation
*  no crc
*  no preamble
*  no sync
*  infinite packet length selected
*  manual calibration (once in setup) needs only be updated if power adjustments are done.
*/	
	
	SpiWriteReg(ss_pin, CC1101_IOCFG2,0x03);  /* Associated to the TX FIFO: Asserts when TX FIFO is full. De-asserts when the 
												   TX FIFO is drained below the TX FIFO
												   threshold. */
	SpiWriteReg(ss_pin, CC1101_IOCFG0,0x06);  /*Asserts when sync word has been sent / received, and de-asserts at the end of the packet. 
												  In RX, the pin will also deassert when a packet is discarded due to address or maximum length 
												  filtering or when the radio enters RXFIFO_OVERFLOW state. In TX the pin will de-assert if the 
												  TX FIFO underflows. */ 
	SpiWriteReg(ss_pin, CC1101_PKTLEN,0x00);  //Packet Length
	SpiWriteReg(ss_pin, CC1101_PKTCTRL0,0x02);//Packet Automation Control // infinit packetlength
	SpiWriteReg(ss_pin, CC1101_PKTCTRL1,0x00);
	SpiWriteReg(ss_pin, CC1101_FSCTRL1,0x06); //Frequency Synthesizer Control
	SpiWriteReg(ss_pin, CC1101_FREQ2,0x21);   //Frequency Control Word, High Byte
	SpiWriteReg(ss_pin, CC1101_FREQ1,0x62);   //Frequency Control Word, Middle Byte
	SpiWriteReg(ss_pin, CC1101_FREQ0,0x76);   //Frequency Control Word, Low Byte
	SpiWriteReg(ss_pin, CC1101_MDMCFG4,0x5b); //Modem Configuration  // DR 80kBaud
	SpiWriteReg(ss_pin, CC1101_MDMCFG3,0x93); //Modem Configuration // DR 80kBaud
	SpiWriteReg(ss_pin, CC1101_MDMCFG2,0x30); //Modem Configuration // ASK / OOK nopreamble nosync , no crc appended
	SpiWriteReg(ss_pin, CC1101_MDMCFG1,0x00); //channel spacing 
	SpiWriteReg(ss_pin, CC1101_MDMCFG0,0xff); // channel spacing 
	SpiWriteReg(ss_pin, CC1101_MCSM1,0x30);   // default settings 
	SpiWriteReg(ss_pin, CC1101_MCSM0,0x29);   //Main Radio Control State Machine Configuration
	SpiWriteReg(ss_pin, CC1101_FOCCFG,0x1D);  //Frequency Offset Compensation Configuration
	SpiWriteReg(ss_pin, CC1101_BSCFG,0x1C);   //Bit Synchronization Configuration
	SpiWriteReg(ss_pin, CC1101_AGCCTRL2,0x07);//AGC Control // mainly used for RX mode
	SpiWriteReg(ss_pin, CC1101_AGCCTRL1,0x00);//AGC Control // mainly used for RX mode
	SpiWriteReg(ss_pin, CC1101_AGCCTRL0,0x92);//AGC Control // mainly used for RX mode
	SpiWriteReg(ss_pin, CC1101_FREND1,0x56);  //Front End RX Configuration
	SpiWriteReg(ss_pin, CC1101_FREND0,0x11);  // the last two bits define the index from the patable to use
	SpiWriteReg(ss_pin, CC1101_FSCAL3,0xEA);  //Frequency Synthesizer Calibration
	SpiWriteReg(ss_pin, CC1101_FSCAL2,0x2A);  //Frequency Synthesizer Calibration
	SpiWriteReg(ss_pin, CC1101_FSCAL1,0x00);  //Frequency Synthesizer Calibration
	SpiWriteReg(ss_pin, CC1101_FSCAL0,0x1F);  //Frequency Synthesizer Calibration
	SpiWriteReg(ss_pin, CC1101_TEST2,0x81);   //Various Test Settings
	SpiWriteReg(ss_pin, CC1101_TEST0,0x35);   //Various Test Settings
	SpiWriteReg(ss_pin, CC1101_TEST0,0x09);   //Various Test Settings
	SpiWriteReg(ss_pin, CC1101_FIFOTHR,0x07); // tx threshold 33bytes
	// manual cal
	SpiStrobe(ss_pin,CC1101_SCAL);
}
/*	Original Library Settings
	SpiWriteReg(CC1101_IOCFG0,  0x06);
	SpiWriteReg(CC1101_FIFOTHR,  0x47);
	SpiWriteReg(CC1101_PKTCTRL0,  0x05);
	SpiWriteReg(CC1101_FSCTRL1,  0x06);
	SpiWriteReg(CC1101_FREQ2,  0x21);
	SpiWriteReg(CC1101_FREQ1,  0x62);
	SpiWriteReg(CC1101_FREQ0,  0x76);
	SpiWriteReg(CC1101_MDMCFG4, 0xF5);
	SpiWriteReg(CC1101_MDMCFG3, 0x83);
	SpiWriteReg(CC1101_MDMCFG2, 0x33);
	SpiWriteReg(CC1101_DEVIATN, 0x15);
	SpiWriteReg(CC1101_MCSM0, 0x18);
	SpiWriteReg(CC1101_FOCCFG, 0x14);
	SpiWriteReg(CC1101_AGCCTRL0, 0x92);
	SpiWriteReg(CC1101_WORCTRL, 0xFB);
	SpiWriteReg(CC1101_FREND0, 0x11);
	SpiWriteReg(CC1101_FSCAL3, 0xE9);
	SpiWriteReg(CC1101_FSCAL2, 0x2A);
	SpiWriteReg(CC1101_FSCAL1, 0x00);
	SpiWriteReg(CC1101_FSCAL0, 0x1F);
	SpiWriteReg(CC1101_TEST2, 0x81);
	SpiWriteReg(CC1101_TEST1, 0x35);
	SpiWriteReg(CC1101_TEST0, 0x09);
*/

/****************************************************************
*FUNCTION NAME:SendData
*FUNCTION     :use CC1101 send data
*INPUT        :txBuffer: data array to send; size: number of data to send, no more than 61
*OUTPUT       :none
****************************************************************/
void ZUHF_CC1101::SendData(byte *txBuffer,byte size)
{
	SpiWriteReg(SS_TX, CC1101_TXFIFO, size);
	SpiWriteBurstReg(SS_TX, CC1101_TXFIFO, txBuffer,size);			//write data to send
	SpiStrobe(SS_TX, CC1101_STX);									//start send	
    while (!digitalRead(GDO0_TX));								// Wait for GDO0_TX to be set -> sync transmitted  
    while (digitalRead(GDO0_TX));								// Wait for GDO0_TX to be cleared -> end of packet
	SpiStrobe(SS_TX,CC1101_SFTX);									//flush TXfifo
}

/****************************************************************
*FUNCTION NAME:SetReceive
*FUNCTION     :set CC1101 to receive state
*INPUT        :none
*OUTPUT       :none
****************************************************************/
void ZUHF_CC1101::SetReceive(void)
{
	SpiStrobe(SS_RX,CC1101_SRX);
}

/****************************************************************
*FUNCTION NAME:CheckReceiveFlag
*FUNCTION     :check receive data or not
*INPUT        :none
*OUTPUT       :flag: 0 no data; 1 receive data 
****************************************************************/
byte ZUHF_CC1101::CheckReceiveFlag(void)
{
	if(digitalRead(GDO0_TX))			//receive data
	{
		while (digitalRead(GDO0_TX));
		return 1;
	}
	else							// no data
	{
		return 0;
	}
}


/****************************************************************
*FUNCTION NAME:ReceiveData
*FUNCTION     :read data received from RXfifo
*INPUT        :rxBuffer: buffer to store data
*OUTPUT       :size of data received
****************************************************************/
byte ZUHF_CC1101::ReceiveData(byte *rxBuffer)
{
	byte size;
	byte status[2];

	if(SpiReadStatus(CC1101_RXBYTES) & BYTES_IN_RXFIFO)
	{
		size=SpiReadReg(CC1101_RXFIFO);
		SpiReadBurstReg(CC1101_RXFIFO,rxBuffer,size);
		SpiReadBurstReg(CC1101_RXFIFO,status,2);
		SpiStrobe(SS_RX,CC1101_SFRX);
		return size;
	}
	else
	{
		SpiStrobe(SS_RX,CC1101_SFRX);
		return 0;
	}
	
}


void ZUHF_CC1101::UpdateFifo(byte *data, int nbytes)
{
  int index = 0;
  while (index < nbytes)
  {
    while(digitalRead(GDO2_TX)); // if/while fifo full pause (de-asserts when below threshold
    SpiWriteBurstReg(SS_TX,CC1101_TXFIFO,&data[index],1);
    index++;
  }
}


ZUHF_CC1101 ZUHF_cc1101;




